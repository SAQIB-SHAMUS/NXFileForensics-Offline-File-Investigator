# NXFileForensics

**An offline, zero-dependency CLI for investigating files on your own machine.**

No API keys. No cloud services. No network calls, ever. Everything runs
locally against files you point it at.

[![tests](https://github.com/SaqibShamus/nxfileforensics/actions/workflows/tests.yml/badge.svg)](https://github.com/SaqibShamus/nxfileforensics/actions/workflows/tests.yml)
![python](https://img.shields.io/badge/python-3.10%2B-blue)
![license](https://img.shields.io/badge/license-MIT-green)
![dependencies](https://img.shields.io/badge/runtime%20dependencies-0-brightgreen)

## Why this exists

"Is this file actually what it claims to be?" is a question you can't
answer just by looking at a filename or icon. NXFileForensics answers
it locally: it checks a file's real signature against its extension,
computes hashes, measures entropy (a proxy for "is this
encrypted/compressed/packed?"), finds exact duplicates across a
directory tree, and does byte-level diffs — all without uploading
anything anywhere.

Useful for: sanity-checking downloads, auditing a folder you inherited,
verifying backups are byte-identical, spotting a `.pdf` that's secretly
an executable, or just understanding what's actually in a messy
directory.

## Features

| Command    | What it does |
|------------|--------------|
| `inspect`  | Metadata, SHA-256, and detected file type for one file |
| `hash`     | md5 / sha1 / sha256 / sha512 digests, one streaming pass |
| `entropy`  | Shannon entropy (bits/byte) — flags likely compressed/encrypted content |
| `strings`  | Extract printable ASCII strings, like the classic `strings` utility |
| `scan`     | Recursively audit a directory: signature mismatches, hidden files, world-writable files, zero-byte files, exact duplicates |
| `diff`     | Byte-level comparison of two files: identical?, first differing offset, similarity % |

Every command supports `--json` for scripting and `--no-color` for
plain terminals. Status output always carries a plain-text tag
(`[OK]`/`[WARN]`/`[ERROR]`/`[INFO]`) — meaning never depends on color.

## Installation

Requires Python 3.10+. No other runtime dependencies.

```bash
git clone https://github.com/SaqibShamus/nxfileforensics.git
cd nxfileforensics
pip install .
```

This installs an `nxff` command on your PATH. For development (editable
install so changes take effect immediately):

```bash
pip install -e .
```

## Quick start

```bash
nxff inspect suspicious_download.pdf
nxff scan ~/Downloads
nxff diff backup_2025.tar backup_2026.tar
```

## Usage

```
nxff [--no-color] [--json] <command> [options]
```

`--no-color` and `--json` work either before or after the subcommand
(`nxff --json scan .` and `nxff scan . --json` are equivalent).

### `inspect` — single-file report

```bash
nxff inspect invoice.pdf
```

```
Path:           invoice.pdf
Size:           14 B
Permissions:    -rw-r--r--
Modified:       2026-09-09T18:44:53+0000
Hidden:         False
Symlink:        False
[OK] World-writable: False
SHA-256:        f7786fc263e4ae2a450c321da34a6d94fe028c7927f4e279c2edf99eb5bf3ca
Detected type:  Windows PE executable/DLL
[WARN] Extension does not match detected file signature
```

That last line is the point: this file is named `.pdf` but its first
bytes are `MZ` — a Windows executable header.

### `hash` — compute digests

```bash
nxff hash file.zip --algo sha256 --algo md5
```

`--algo` is repeatable; defaults to `sha256` alone if omitted.

### `entropy` — spot compressed/encrypted content

```bash
nxff entropy dump.bin
```

Values close to 8.0 bits/byte indicate compressed, encrypted, or packed
data. This is a *signal*, not a verdict — legitimate ZIPs and JPEGs are
high-entropy too. It's most useful during `scan`, where a surprisingly
high-entropy `.txt` or `.docx` is worth a second look.

### `strings` — extract printable text

```bash
nxff strings unknown_binary --min-length 6 --limit 50
```

### `scan` — audit a whole directory

```bash
nxff scan ./project --max-depth 4
```

Reports, in one pass:
- files whose extension disagrees with their detected signature
- world-writable files (POSIX systems)
- exact duplicate files (grouped by size + SHA-256)
- per-file errors (permission denied, etc.) without aborting the scan

Symlinks are never followed during a scan, so symlink loops can't cause
infinite recursion.

### `diff` — byte-level file comparison

```bash
nxff diff old_export.csv new_export.csv
```

```
[WARN] files differ
Size A: 128 KB   Size B: 129 KB
First difference at byte offset: 4096
Similarity: 97.3%
```

## Example: JSON output for scripting

```bash
nxff --json scan . | python3 -c "
import json, sys
data = json.load(sys.stdin)
print(f\"{data['files_scanned']} files, {len(data['duplicate_groups'])} duplicate groups\")
"
```

## Architecture

```
CLI layer (cli.py — argparse, printing, exit codes)
    ↓
Core logic (core/*.py — pure functions, no argparse, no printing)
    ↓
Local filesystem only
```

Logic and CLI plumbing are kept separate on purpose: every `core`
module can be imported and tested (or reused in your own script)
without spawning a subprocess or touching argparse.

```
src/nxfileforensics/
├── cli.py              command-line parsing and dispatch
├── errors.py           exception types → friendly CLI messages
├── core/
│   ├── hashing.py       streaming multi-algorithm hashing
│   ├── signatures.py    magic-byte detection + extension mismatch
│   ├── metadata.py      cross-platform file metadata
│   ├── entropy.py       Shannon entropy
│   ├── strings_extract.py  printable-string extraction
│   ├── diff.py           byte-level file comparison
│   └── scanner.py        recursive directory audit
└── utils/formatting.py  color-safe terminal output helpers
```

## Security

See [SECURITY.md](SECURITY.md) for the full threat model. Summary:
this tool is read-only, makes no network calls, never executes file
content, streams all reads so file size never translates into
unbounded memory use, and never follows symlinks during a scan.

## Performance

All I/O-bound operations (`hash`, `entropy`, `strings`, `diff`, `scan`)
read files in fixed-size (1 MiB) chunks, so memory use does not scale
with file size. No formal throughput benchmarks have been published yet
— if you run one, a PR adding real numbers (with your hardware and
methodology noted) is welcome.

## Limitations

- `strings` extracts ASCII printable runs only; it does not currently
  extract UTF-16/wide-character strings (common in Windows binaries).
- The signature database in `signatures.py` covers common formats
  (images, archives, PDFs, executables, audio) but is intentionally a
  curated list, not an exhaustive magic-number database.
- `scan` has no separate file-count/size budget beyond streaming I/O —
  scanning a very large tree takes proportionally long.
- Ownership/permission fields (`owner_uid`, `world_writable`, etc.)
  are `None` on platforms without POSIX permission bits (e.g. Windows).

## Roadmap

- [ ] Optional UTF-16 string extraction
- [ ] `--exclude` glob patterns for `scan`
- [ ] Configurable signature database (user-supplied magic-byte rules)

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Bug reports and small,
focused PRs are especially welcome — this project intentionally stays
small and dependency-free.

## License

[MIT](LICENSE)
