"""Example: use NXFileForensics's core modules directly from Python,
without going through the CLI.

Run from the repo root after `pip install -e .`:

    python3 examples/scan_as_library.py .
"""

from __future__ import annotations

import sys

from nxfileforensics.core.scanner import scan_directory


def main() -> int:
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    report = scan_directory(target)

    print(f"Scanned {report.files_scanned} file(s) under {report.root}")

    mismatches = [f for f in report.findings if f.extension_mismatch]
    if mismatches:
        print(f"\n{len(mismatches)} extension/signature mismatch(es):")
        for f in mismatches:
            print(f"  - {f.path} looks like: {f.detected_type}")

    if report.duplicate_groups:
        print(f"\n{len(report.duplicate_groups)} duplicate group(s):")
        for group in report.duplicate_groups:
            print(f"  - {len(group)} identical files: {group}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
