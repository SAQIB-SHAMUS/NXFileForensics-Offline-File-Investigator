# Changelog

All notable changes to this project are documented in this file.
Format loosely follows [Keep a Changelog](https://keepachangelog.com/),
and this project uses [Semantic Versioning](https://semver.org/).

## [0.1.0] — Initial release

### Added
- `inspect` — file metadata (size, permissions, timestamps, owner where
  applicable), SHA-256 hash, and signature-based type detection in one
  view.
- `hash` — compute md5/sha1/sha256/sha512 digests in a single streaming
  pass.
- `entropy` — Shannon entropy (bits/byte) with a high-entropy flag for
  likely compressed/encrypted/packed content.
- `strings` — printable ASCII string extraction with configurable
  minimum length, correct across internal chunk boundaries.
- `scan` — recursive directory scan reporting extension/signature
  mismatches, hidden files, world-writable files (POSIX), zero-byte
  files, and exact duplicate groups (by size + SHA-256).
- `diff` — byte-level comparison of two files: identical/not, first
  differing offset, and similarity percentage.
- `--json` output on every command for scripting.
- `--no-color` for environments without ANSI support; all status
  output also carries a plain-text `[OK]/[WARN]/[ERROR]/[INFO]` tag so
  meaning never depends on color alone.

### Known limitations (see README)
- `strings` extracts ASCII only, not UTF-16/wide-character strings.
- `signatures` covers a curated set of common formats, not an
  exhaustive magic-number database.
- No file-count/size budget guard in `scan` beyond streaming I/O.
