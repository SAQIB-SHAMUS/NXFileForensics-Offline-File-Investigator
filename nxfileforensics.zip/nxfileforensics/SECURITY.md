# Security Policy

## Scope and threat model

NXFileForensics is a local, offline, read-mostly CLI tool. It:

- Makes **no network requests** of any kind (no telemetry, no update
  checks, no analytics).
- Only reads files the user explicitly points it at, or that live under
  a directory the user explicitly passes to `scan`.
- Never executes, imports, or evaluates the content of files it inspects.
  Detection is purely byte-pattern matching (see `core/signatures.py`);
  it never runs `eval`, `exec`, or `subprocess` with file content.
- Never modifies or deletes files. Every command is read-only.

Given that, the realistic threat surface is:

1. **Malicious filenames or paths** (path traversal, symlink tricks)
   passed to a command.
2. **Malformed/adversarial file content** designed to crash the tool or
   cause excessive resource use (e.g. a crafted file meant to make
   `entropy` or `strings` consume unbounded memory).
3. **Symlink loops** during `scan` causing infinite recursion.

## Mitigations already in place

- All file reads are chunked/streamed (`hashing.py`, `entropy.py`,
  `strings_extract.py`, `diff.py`), so file size never translates into
  unbounded memory use.
- `scan` uses `os.walk(..., followlinks=False)`, so it never follows
  symlinks into a loop or outside the target tree.
- Per-file errors during `scan` (permission denied, broken symlink,
  file deleted mid-scan) are caught and reported per-file; they do not
  abort the whole scan or raise a traceback to the user.
- No `eval`, `exec`, or `shell=True` anywhere in the codebase.

## Known limitations

- `scan` does not currently enforce a maximum file count or total-size
  budget; scanning an extremely large tree will simply take
  proportionally long. There is no separate resource-exhaustion guard
  beyond streaming I/O.
- Signature detection is a small, curated magic-byte table, not an
  exhaustive database — it is a heuristic aid, not a guarantee of file
  type.

## Reporting a vulnerability

If you find a security issue, please open a GitHub issue with the
`security` label, or, for anything you'd rather not disclose publicly
first, contact the maintainer listed in the repository profile before
filing a public issue. Please include:

- A description of the issue and its impact
- Steps or a minimal file/command to reproduce it
- The version (`nxff --version`) and platform you tested on

There is currently no bug bounty program.
