"""Command-line interface for NXFileForensics.

    nxff inspect <path>            file metadata, hashes, detected type
    nxff hash <path>               compute hash digest(s)
    nxff entropy <path>            Shannon entropy (bits/byte)
    nxff strings <path>            extract printable ASCII strings
    nxff scan <directory>          recursive anomaly + duplicate scan
    nxff diff <file_a> <file_b>    byte-level comparison

Every command accepts --json for machine-readable output and every
subcommand fails with a short "Error: ..." message (never a raw
traceback) when given bad input.
"""

from __future__ import annotations

import argparse
import json
import sys

from nxfileforensics import __version__
from nxfileforensics.core import diff as diff_mod
from nxfileforensics.core import entropy as entropy_mod
from nxfileforensics.core import hashing
from nxfileforensics.core import metadata as metadata_mod
from nxfileforensics.core import scanner
from nxfileforensics.core import signatures
from nxfileforensics.core import strings_extract
from nxfileforensics.errors import NxffError
from nxfileforensics.utils.formatting import human_size, supports_color, tag


def _global_flags_parser() -> argparse.ArgumentParser:
    """Shared --no-color/--json flags, usable before OR after the subcommand.

    argparse does not let a subparser fall back to its parent's optional
    arguments, so without this, `nxff scan . --no-color` would fail even
    though `nxff --no-color scan .` works. Using `parents=` on every
    subparser fixes that asymmetry.

    default=SUPPRESS on the subparser copies is required: argparse parses
    the subparser's defaults *after* the top-level parser's, so without
    SUPPRESS a `--json` given before the subcommand would be silently
    reset to False by the subparser's own default when not repeated
    after the subcommand.
    """
    parent = argparse.ArgumentParser(add_help=False)
    parent.add_argument("--no-color", action="store_true", default=argparse.SUPPRESS, help="disable colored output")
    parent.add_argument("--json", action="store_true", default=argparse.SUPPRESS, help="emit machine-readable JSON")
    return parent


def build_parser() -> argparse.ArgumentParser:
    global_flags = _global_flags_parser()

    parser = argparse.ArgumentParser(
        prog="nxff",
        description="NXFileForensics — offline, local file investigation toolkit.",
    )
    # Real (non-suppressed) defaults live only here, so the flags always
    # exist on the final namespace even if never passed at all.
    parser.add_argument("--no-color", action="store_true", help="disable colored output")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    parser.add_argument("--version", action="version", version=f"nxff {__version__}")

    sub = parser.add_subparsers(dest="command", required=True)

    p_inspect = sub.add_parser(
        "inspect", help="show metadata, hashes, and detected type for a file", parents=[global_flags]
    )
    p_inspect.add_argument("path")

    p_hash = sub.add_parser("hash", help="compute hash digest(s) for a file", parents=[global_flags])
    p_hash.add_argument("path")
    p_hash.add_argument(
        "--algo",
        action="append",
        choices=["md5", "sha1", "sha256", "sha512"],
        help="algorithm to compute (repeatable). Default: sha256",
    )

    p_entropy = sub.add_parser(
        "entropy", help="compute Shannon entropy (bits/byte) for a file", parents=[global_flags]
    )
    p_entropy.add_argument("path")

    p_strings = sub.add_parser(
        "strings", help="extract printable ASCII strings from a file", parents=[global_flags]
    )
    p_strings.add_argument("path")
    p_strings.add_argument("--min-length", type=int, default=4, help="minimum string length (default: 4)")
    p_strings.add_argument("--limit", type=int, default=200, help="max strings to print (default: 200, 0 = unlimited)")

    p_scan = sub.add_parser(
        "scan", help="recursively scan a directory for anomalies and duplicates", parents=[global_flags]
    )
    p_scan.add_argument("path")
    p_scan.add_argument("--max-depth", type=int, default=None, help="limit recursion depth")

    p_diff = sub.add_parser("diff", help="byte-level comparison of two files", parents=[global_flags])
    p_diff.add_argument("file_a")
    p_diff.add_argument("file_b")

    return parser


def _print(text: str) -> None:
    print(text)


def _cmd_inspect(args, use_color: bool) -> dict:
    meta = metadata_mod.get_metadata(args.path)
    hashes = hashing.compute_hashes(args.path, algorithms=["sha256"])
    mismatch = signatures.check_extension_mismatch(args.path)
    result = {
        **meta.to_dict(),
        "sha256": hashes["sha256"],
        "detected_type": mismatch.detected.name if mismatch.detected else "unknown",
        "extension_mismatch": mismatch.mismatched,
    }
    if not args.json:
        _print(f"Path:           {result['path']}")
        _print(f"Size:           {human_size(result['size_bytes'])}")
        _print(f"Permissions:    {result['permissions']}")
        _print(f"Modified:       {result['modified']}")
        _print(f"Hidden:         {result['is_hidden']}")
        _print(f"Symlink:        {result['is_symlink']}")
        if result["world_writable"] is not None:
            level = "warn" if result["world_writable"] else "ok"
            _print(tag(level, f"World-writable: {result['world_writable']}", use_color))
        _print(f"SHA-256:        {result['sha256']}")
        _print(f"Detected type:  {result['detected_type']}")
        if result["extension_mismatch"]:
            _print(tag("warn", "Extension does not match detected file signature", use_color))
        else:
            _print(tag("ok", "Extension matches detected file signature", use_color))
    return result


def _cmd_hash(args, use_color: bool) -> dict:
    algos = args.algo or ["sha256"]
    result = hashing.compute_hashes(args.path, algorithms=algos)
    if not args.json:
        for algo, digest in result.items():
            _print(f"{algo:8s} {digest}")
    return result


def _cmd_entropy(args, use_color: bool) -> dict:
    value = entropy_mod.shannon_entropy(args.path)
    high = value >= entropy_mod.HIGH_ENTROPY_THRESHOLD
    result = {"path": args.path, "entropy_bits_per_byte": round(value, 4), "high_entropy": high}
    if not args.json:
        _print(f"Entropy: {result['entropy_bits_per_byte']} bits/byte")
        if high:
            _print(tag("warn", "High entropy — likely compressed, encrypted, or packed", use_color))
        else:
            _print(tag("info", "Entropy within typical range for uncompressed data", use_color))
    return result


def _cmd_strings(args, use_color: bool) -> dict:
    if args.min_length < 1:
        raise NxffError("--min-length must be >= 1")
    found = []
    for i, s in enumerate(strings_extract.extract_strings(args.path, min_length=args.min_length)):
        if args.limit and i >= args.limit:
            break
        found.append(s)
    if not args.json:
        for s in found:
            _print(s)
        if args.limit and len(found) >= args.limit:
            _print(tag("info", f"output truncated at {args.limit} strings (use --limit 0 for unlimited)", use_color))
    return {"path": args.path, "count": len(found), "strings": found}


def _cmd_scan(args, use_color: bool) -> dict:
    report = scanner.scan_directory(args.path, max_depth=args.max_depth)
    if not args.json:
        _print(f"Scanned {report.files_scanned} file(s) under {report.root}")
        if report.errors:
            _print(tag("warn", f"{report.errors} file(s) could not be read", use_color))

        flagged = [f for f in report.findings if f.extension_mismatch]
        for f in flagged:
            _print(tag("warn", f"extension mismatch: {f.path} (looks like {f.detected_type})", use_color))

        writable = [f for f in report.findings if f.world_writable]
        for f in writable:
            _print(tag("warn", f"world-writable: {f.path}", use_color))

        if report.duplicate_groups:
            _print(tag("info", f"{len(report.duplicate_groups)} duplicate group(s) found:", use_color))
            for group in report.duplicate_groups:
                _print(f"  - {len(group)} copies:")
                for p in group:
                    _print(f"      {p}")

        if not flagged and not writable and not report.duplicate_groups:
            _print(tag("ok", "no anomalies or duplicates found", use_color))
    return report.to_dict()


def _cmd_diff(args, use_color: bool) -> dict:
    result = diff_mod.diff_files(args.file_a, args.file_b)
    if not args.json:
        if result.identical:
            _print(tag("ok", "files are identical", use_color))
        else:
            _print(tag("warn", "files differ", use_color))
            _print(f"Size A: {human_size(result.size_a)}   Size B: {human_size(result.size_b)}")
            if result.first_difference_offset is not None:
                _print(f"First difference at byte offset: {result.first_difference_offset}")
            _print(f"Similarity: {result.similarity_pct()}%")
    return result.to_dict()


_COMMANDS = {
    "inspect": _cmd_inspect,
    "hash": _cmd_hash,
    "entropy": _cmd_entropy,
    "strings": _cmd_strings,
    "scan": _cmd_scan,
    "diff": _cmd_diff,
}


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    use_color = supports_color(args.no_color)

    handler = _COMMANDS[args.command]
    try:
        result = handler(args, use_color)
    except NxffError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(f"Error: path does not exist: {exc.filename or exc}", file=sys.stderr)
        return 1
    except PermissionError as exc:
        print(f"Error: permission denied: {exc.filename or exc}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
