"""Custom exceptions.

Every exception here is caught at the CLI boundary and turned into a
short, human-readable message instead of a raw Python traceback. Internal
callers (tests, library users) still get real exception types and can
inspect `.path` / `.detail` for programmatic handling.
"""

from __future__ import annotations


class NxffError(Exception):
    """Base class for all NXFileForensics errors."""


class PathNotFoundError(NxffError):
    def __init__(self, path: str):
        self.path = path
        super().__init__(f"path does not exist: {path}")


class NotAFileError(NxffError):
    def __init__(self, path: str):
        self.path = path
        super().__init__(f"expected a file, got a directory: {path}")


class NotADirectoryErrorNxff(NxffError):
    def __init__(self, path: str):
        self.path = path
        super().__init__(f"expected a directory, got a file: {path}")


class UnreadableFileError(NxffError):
    def __init__(self, path: str, detail: str = ""):
        self.path = path
        self.detail = detail
        msg = f"cannot read file: {path}"
        if detail:
            msg += f" ({detail})"
        super().__init__(msg)


class InvalidArgumentError(NxffError):
    def __init__(self, message: str):
        super().__init__(message)
