"""NXFileForensics — offline, local file investigation toolkit.

This package contains no network calls, no telemetry, and no external
service dependencies. Every command operates only on files the user
explicitly points it at.
"""

__version__ = "0.1.0"
