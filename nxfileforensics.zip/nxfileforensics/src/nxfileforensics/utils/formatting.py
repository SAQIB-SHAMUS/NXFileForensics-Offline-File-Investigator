"""Terminal output helpers.

Every status tag carries a plain-text marker ([OK]/[WARN]/[ERROR]/[INFO])
so meaning never depends on color alone. Color is an optional bonus, and
is skipped automatically when stdout is not a terminal or when --no-color
is passed.
"""

from __future__ import annotations

import sys

_CODES = {
    "green": "\033[32m",
    "yellow": "\033[33m",
    "red": "\033[31m",
    "cyan": "\033[36m",
    "bold": "\033[1m",
    "reset": "\033[0m",
}

_TAGS = {
    "ok": "[OK]",
    "warn": "[WARN]",
    "error": "[ERROR]",
    "info": "[INFO]",
}

_TAG_COLOR = {
    "ok": "green",
    "warn": "yellow",
    "error": "red",
    "info": "cyan",
}


def supports_color(no_color: bool) -> bool:
    if no_color:
        return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def tag(level: str, text: str, use_color: bool) -> str:
    marker = _TAGS[level]
    if not use_color:
        return f"{marker} {text}"
    color = _CODES[_TAG_COLOR[level]]
    return f"{color}{marker}{_CODES['reset']} {text}"


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.2f} {unit}"
        size /= 1024
    return f"{size:.2f} PB"
