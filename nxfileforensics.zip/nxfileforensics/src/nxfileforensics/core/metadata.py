"""Cross-platform filesystem metadata extraction.

Fields that only exist on POSIX systems (owner uid/gid, mode bits, world-
writable checks) degrade gracefully to `None` on platforms where they are
meaningless, rather than raising.
"""

from __future__ import annotations

import stat
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from nxfileforensics.errors import PathNotFoundError, UnreadableFileError


@dataclass
class FileMetadata:
    path: str
    size_bytes: int
    is_symlink: bool
    is_hidden: bool
    permissions: str
    modified: str
    accessed: str
    created_or_ctime_changed: str
    owner_uid: int | None
    group_gid: int | None
    world_writable: bool | None

    def to_dict(self) -> dict:
        return asdict(self)


def _iso(ts: float) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(ts))


def get_metadata(path: str | Path) -> FileMetadata:
    path = Path(path)
    if not path.exists() and not path.is_symlink():
        raise PathNotFoundError(str(path))

    try:
        st = path.lstat()
    except OSError as exc:
        raise UnreadableFileError(str(path), str(exc)) from exc

    is_symlink = path.is_symlink()
    world_writable = None
    owner_uid = None
    group_gid = None
    try:
        owner_uid = st.st_uid
        group_gid = st.st_gid
        world_writable = bool(st.st_mode & stat.S_IWOTH)
    except AttributeError:
        # st_uid/st_gid are absent on some platforms (e.g. Windows)
        pass

    return FileMetadata(
        path=str(path),
        size_bytes=st.st_size,
        is_symlink=is_symlink,
        is_hidden=path.name.startswith("."),
        permissions=stat.filemode(st.st_mode),
        modified=_iso(st.st_mtime),
        accessed=_iso(st.st_atime),
        created_or_ctime_changed=_iso(st.st_ctime),
        owner_uid=owner_uid,
        group_gid=group_gid,
        world_writable=world_writable,
    )
