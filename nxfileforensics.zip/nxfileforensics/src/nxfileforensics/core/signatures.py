"""File-type identification by magic bytes, independent of file extension.

This is the core of NXFileForensics's "is this file what it claims to
be?" check: a file's real type is determined by the bytes at its head,
not by whatever extension someone gave it. A textbook forensic red flag
is a file whose signature and extension disagree (e.g. `invoice.pdf`
that is actually a Windows executable).

The signature table is intentionally small and dependency-free rather
than an exhaustive magic-number database. It covers common formats
people actually encounter day to day.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from nxfileforensics.errors import UnreadableFileError

_SNIFF_BYTES = 64  # enough for every signature below, including offset ones


@dataclass(frozen=True)
class Signature:
    name: str
    magic: bytes
    offset: int
    extensions: frozenset[str]


_SIGNATURES: tuple[Signature, ...] = (
    Signature("PNG image", b"\x89PNG\r\n\x1a\n", 0, frozenset({".png"})),
    Signature("JPEG image", b"\xff\xd8\xff", 0, frozenset({".jpg", ".jpeg"})),
    Signature("GIF image", b"GIF87a", 0, frozenset({".gif"})),
    Signature("GIF image", b"GIF89a", 0, frozenset({".gif"})),
    Signature("BMP image", b"BM", 0, frozenset({".bmp"})),
    Signature("PDF document", b"%PDF-", 0, frozenset({".pdf"})),
    Signature(
        "ZIP archive (also docx/xlsx/pptx/jar/apk)",
        b"PK\x03\x04",
        0,
        frozenset({".zip", ".docx", ".xlsx", ".pptx", ".jar", ".apk", ".epub"}),
    ),
    Signature("GZIP archive", b"\x1f\x8b", 0, frozenset({".gz", ".tgz"})),
    Signature("RAR archive", b"Rar!\x1a\x07", 0, frozenset({".rar"})),
    Signature("7-Zip archive", b"7z\xbc\xaf\x27\x1c", 0, frozenset({".7z"})),
    Signature("ELF executable (Linux)", b"\x7fELF", 0, frozenset({"", ".elf", ".so", ".bin"})),
    Signature("Windows PE executable/DLL", b"MZ", 0, frozenset({".exe", ".dll", ".sys"})),
    Signature("SQLite database", b"SQLite format 3\x00", 0, frozenset({".db", ".sqlite", ".sqlite3"})),
    Signature("Java class file", b"\xca\xfe\xba\xbe", 0, frozenset({".class"})),
    Signature("OGG media", b"OggS", 0, frozenset({".ogg", ".oga", ".ogv"})),
    Signature("MP3 audio (ID3 tag)", b"ID3", 0, frozenset({".mp3"})),
    Signature("WAV audio", b"WAVE", 8, frozenset({".wav"})),
    Signature("RIFF/AVI container", b"AVI ", 8, frozenset({".avi"})),
)


def identify(path: str | Path) -> Signature | None:
    """Return the first matching signature for a file, or None if unknown."""
    path = Path(path)
    try:
        with path.open("rb") as fh:
            head = fh.read(_SNIFF_BYTES)
    except OSError as exc:
        raise UnreadableFileError(str(path), str(exc)) from exc

    for sig in _SIGNATURES:
        end = sig.offset + len(sig.magic)
        if len(head) >= end and head[sig.offset:end] == sig.magic:
            return sig
    return None


@dataclass(frozen=True)
class MismatchResult:
    detected: Signature | None
    extension: str
    mismatched: bool


def check_extension_mismatch(path: str | Path) -> MismatchResult:
    """Compare a file's declared extension against its detected signature.

    `mismatched` is True only when a signature WAS detected and the
    file's extension is not among the extensions normally associated
    with that signature. Files with unrecognized signatures (plain
    text, unknown/custom formats, etc.) are never flagged — there is
    nothing to contradict.
    """
    path = Path(path)
    ext = path.suffix.lower()
    sig = identify(path)
    if sig is None:
        return MismatchResult(detected=None, extension=ext, mismatched=False)
    mismatched = ext not in sig.extensions
    return MismatchResult(detected=sig, extension=ext, mismatched=mismatched)
