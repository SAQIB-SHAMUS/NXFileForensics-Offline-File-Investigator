"""Byte-level comparison of two files.

Deliberately not a text/line diff (use your VCS or `diff` for that).
This answers the forensic question "are these two files identical, and
if not, where do they first diverge and how much do they differ?" while
streaming both files in lockstep so memory use stays constant regardless
of file size.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from nxfileforensics.errors import UnreadableFileError

_CHUNK_SIZE = 1024 * 1024


@dataclass
class DiffResult:
    identical: bool
    size_a: int
    size_b: int
    first_difference_offset: int | None
    differing_bytes: int
    bytes_compared: int

    def to_dict(self) -> dict:
        return {
            "identical": self.identical,
            "size_a": self.size_a,
            "size_b": self.size_b,
            "first_difference_offset": self.first_difference_offset,
            "differing_bytes": self.differing_bytes,
            "bytes_compared": self.bytes_compared,
            "similarity_pct": self.similarity_pct(),
        }

    def similarity_pct(self) -> float:
        if self.bytes_compared == 0:
            return 100.0 if self.size_a == self.size_b else 0.0
        matching = self.bytes_compared - self.differing_bytes
        return round(100.0 * matching / self.bytes_compared, 2)


def diff_files(path_a: str | Path, path_b: str | Path) -> DiffResult:
    path_a, path_b = Path(path_a), Path(path_b)
    try:
        size_a = path_a.stat().st_size
        size_b = path_b.stat().st_size
    except OSError as exc:
        raise UnreadableFileError(str(exc)) from exc

    first_diff = None
    differing = 0
    compared = 0

    try:
        with path_a.open("rb") as fa, path_b.open("rb") as fb:
            offset = 0
            while True:
                chunk_a = fa.read(_CHUNK_SIZE)
                chunk_b = fb.read(_CHUNK_SIZE)
                if not chunk_a and not chunk_b:
                    break
                length = max(len(chunk_a), len(chunk_b))
                for i in range(length):
                    ba = chunk_a[i] if i < len(chunk_a) else None
                    bb = chunk_b[i] if i < len(chunk_b) else None
                    compared += 1
                    if ba != bb:
                        differing += 1
                        if first_diff is None:
                            first_diff = offset + i
                offset += length
    except OSError as exc:
        raise UnreadableFileError(str(exc)) from exc

    return DiffResult(
        identical=(differing == 0 and size_a == size_b),
        size_a=size_a,
        size_b=size_b,
        first_difference_offset=first_diff,
        differing_bytes=differing,
        bytes_compared=compared,
    )
