"""Streaming hash computation.

Files are read in fixed-size chunks so hashing a multi-gigabyte file
never requires loading it into memory at once.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable

from nxfileforensics.errors import UnreadableFileError

_CHUNK_SIZE = 1024 * 1024  # 1 MiB

_SUPPORTED_ALGOS = ("md5", "sha1", "sha256", "sha512")

# NOTE: MD5 and SHA-1 are included only for compatibility with existing
# records/tooling that reference them. They are not collision-resistant
# and should not be relied on for security-sensitive integrity checks.
# Prefer sha256 or sha512.


def compute_hashes(path: str | Path, algorithms: Iterable[str] = _SUPPORTED_ALGOS) -> dict[str, str]:
    """Compute one or more hash digests for a file in a single pass.

    Raises:
        UnreadableFileError: if the file cannot be opened or read.
        ValueError: if an unsupported algorithm name is requested.
    """
    algorithms = list(algorithms)
    for algo in algorithms:
        if algo not in _SUPPORTED_ALGOS:
            raise ValueError(
                f"unsupported algorithm '{algo}'; choose from {', '.join(_SUPPORTED_ALGOS)}"
            )

    hashers = {algo: hashlib.new(algo) for algo in algorithms}
    path = Path(path)
    try:
        with path.open("rb") as fh:
            while True:
                chunk = fh.read(_CHUNK_SIZE)
                if not chunk:
                    break
                for hasher in hashers.values():
                    hasher.update(chunk)
    except OSError as exc:
        raise UnreadableFileError(str(path), str(exc)) from exc

    return {algo: hasher.hexdigest() for algo, hasher in hashers.items()}
