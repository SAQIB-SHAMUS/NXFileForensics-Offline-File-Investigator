"""Shannon entropy estimation.

High-entropy files (close to 8 bits/byte) are typically compressed,
encrypted, or packed. This is a signal, not a verdict — a legitimate
ZIP or JPEG is high-entropy too. It is most useful in `scan` mode for
flagging files whose entropy is surprising given their extension
(e.g. a `.txt` or `.docx-looking` file with 7.9+ bits/byte entropy).
"""

from __future__ import annotations

import math
from pathlib import Path

from nxfileforensics.errors import UnreadableFileError

_CHUNK_SIZE = 1024 * 1024
HIGH_ENTROPY_THRESHOLD = 7.5  # bits/byte; commonly used rule-of-thumb cutoff


def shannon_entropy(path: str | Path) -> float:
    """Compute Shannon entropy (bits per byte, 0.0-8.0) via a single
    streaming pass, so file size does not bound memory use."""
    path = Path(path)
    counts = [0] * 256
    total = 0
    try:
        with path.open("rb") as fh:
            while True:
                chunk = fh.read(_CHUNK_SIZE)
                if not chunk:
                    break
                total += len(chunk)
                for b in chunk:
                    counts[b] += 1
    except OSError as exc:
        raise UnreadableFileError(str(path), str(exc)) from exc

    if total == 0:
        return 0.0

    entropy = 0.0
    for count in counts:
        if count == 0:
            continue
        p = count / total
        entropy -= p * math.log2(p)
    return entropy


def is_high_entropy(path: str | Path, threshold: float = HIGH_ENTROPY_THRESHOLD) -> bool:
    return shannon_entropy(path) >= threshold
