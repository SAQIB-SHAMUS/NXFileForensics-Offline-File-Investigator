"""Recursive directory scan.

Walks a directory tree and, for every regular file, collects:
  - size and sha256
  - extension/signature mismatch
  - hidden-file status
  - world-writable permission (POSIX only)
  - zero-byte status

It then groups files by (size, sha256) to report exact duplicates.

Safety notes:
  - Symlinks are never followed during the walk (os.walk(followlinks=False)),
    which avoids symlink-loop infinite recursion and accidental traversal
    outside the target directory.
  - Per-file errors (permission denied, broken symlink, file removed mid-scan)
    are caught and recorded rather than aborting the whole scan.
  - `max_depth=None` means unlimited; set an integer to bound traversal.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from nxfileforensics.core.hashing import compute_hashes
from nxfileforensics.core.signatures import check_extension_mismatch
from nxfileforensics.errors import NotADirectoryErrorNxff, PathNotFoundError


@dataclass
class FileFinding:
    path: str
    size_bytes: int
    sha256: str | None
    hidden: bool
    zero_byte: bool
    world_writable: bool | None
    extension_mismatch: bool
    detected_type: str | None
    error: str | None = None


@dataclass
class ScanReport:
    root: str
    files_scanned: int
    errors: int
    findings: list[FileFinding] = field(default_factory=list)
    duplicate_groups: list[list[str]] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "root": self.root,
            "files_scanned": self.files_scanned,
            "errors": self.errors,
            "findings": [vars(f) for f in self.findings],
            "duplicate_groups": self.duplicate_groups,
        }


def scan_directory(root: str | Path, max_depth: int | None = None) -> ScanReport:
    root = Path(root)
    if not root.exists():
        raise PathNotFoundError(str(root))
    if not root.is_dir():
        raise NotADirectoryErrorNxff(str(root))

    root_depth = len(root.resolve().parts)
    findings: list[FileFinding] = []
    by_size_hash: dict[tuple[int, str], list[str]] = {}
    error_count = 0

    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        current_depth = len(Path(dirpath).resolve().parts) - root_depth
        if max_depth is not None and current_depth >= max_depth:
            dirnames[:] = []  # stop descending further

        for name in filenames:
            fpath = Path(dirpath) / name
            try:
                size = fpath.stat().st_size
                hashes = compute_hashes(fpath, algorithms=["sha256"])
                sha256 = hashes["sha256"]
                mismatch = check_extension_mismatch(fpath)
                world_writable = None
                try:
                    import stat as _stat
                    world_writable = bool(fpath.stat().st_mode & _stat.S_IWOTH)
                except AttributeError:
                    pass

                finding = FileFinding(
                    path=str(fpath),
                    size_bytes=size,
                    sha256=sha256,
                    hidden=name.startswith("."),
                    zero_byte=(size == 0),
                    world_writable=world_writable,
                    extension_mismatch=mismatch.mismatched,
                    detected_type=mismatch.detected.name if mismatch.detected else None,
                )
                by_size_hash.setdefault((size, sha256), []).append(str(fpath))
            except OSError as exc:
                finding = FileFinding(
                    path=str(fpath),
                    size_bytes=-1,
                    sha256=None,
                    hidden=name.startswith("."),
                    zero_byte=False,
                    world_writable=None,
                    extension_mismatch=False,
                    detected_type=None,
                    error=str(exc),
                )
                error_count += 1

            findings.append(finding)

    duplicate_groups = [paths for paths in by_size_hash.values() if len(paths) > 1]

    return ScanReport(
        root=str(root),
        files_scanned=len(findings),
        errors=error_count,
        findings=findings,
        duplicate_groups=duplicate_groups,
    )
