"""Printable-string extraction, similar in spirit to the Unix `strings`
utility.

Only ASCII printable runs are extracted (0x20-0x7e). This is a
deliberate scope limitation — see README "Limitations" — rather than an
oversight; wide-character (UTF-16) string extraction is a reasonable
future addition.

Reads the file in fixed-size chunks so it never depends on file size,
while correctly handling printable runs that straddle a chunk boundary.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

from nxfileforensics.errors import UnreadableFileError

_CHUNK_SIZE = 1024 * 1024
_PRINTABLE_MIN, _PRINTABLE_MAX = 0x20, 0x7E


def _is_printable(byte: int) -> bool:
    return _PRINTABLE_MIN <= byte <= _PRINTABLE_MAX


def extract_strings(path: str | Path, min_length: int = 4) -> Iterator[str]:
    """Yield printable ASCII substrings of at least `min_length` characters."""
    if min_length < 1:
        raise ValueError("min_length must be >= 1")

    path = Path(path)
    buf = bytearray()
    try:
        with path.open("rb") as fh:
            while True:
                chunk = fh.read(_CHUNK_SIZE)
                if not chunk:
                    break
                for byte in chunk:
                    if _is_printable(byte):
                        buf.append(byte)
                    else:
                        if len(buf) >= min_length:
                            yield buf.decode("ascii")
                        buf.clear()
    except OSError as exc:
        raise UnreadableFileError(str(path), str(exc)) from exc

    if len(buf) >= min_length:
        yield buf.decode("ascii")
