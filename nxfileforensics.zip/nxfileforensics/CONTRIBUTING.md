# Contributing to NXFileForensics

Thanks for considering a contribution. This project stays deliberately
small and dependency-free — please keep that in mind when proposing
changes.

## Project principles (please read before opening a PR)

- **Offline only.** No network calls, no telemetry, no "phone home"
  update checks — ever.
- **Zero required runtime dependencies.** Anything beyond the Python
  standard library needs a strong justification in the PR description.
- **CLI-first.** No GUI/web dashboard. If you want a wrapper UI, build
  it as a separate project that shells out to `nxff`.
- **Read-only by default.** Commands must not modify or delete user
  files. If you add a command that could ever write/delete, it needs a
  `--dry-run` mode and an explicit confirmation step.
- **No raw tracebacks for user-facing errors.** Expected failure modes
  (missing file, bad permissions, bad arguments) should raise or be
  wrapped in an `NxffError` subclass from `errors.py` and surface as
  `Error: ...` — see `cli.py::main`.

## Getting started

```bash
git clone https://github.com/SaqibShamus/nxfileforensics.git
cd nxfileforensics
python3 -m venv .venv
source .venv/bin/activate       # .venv\Scripts\activate on Windows
pip install -e .
```

No `requirements.txt` is needed for runtime use — the project has no
runtime dependencies. If you add developer tooling (linters, etc.),
document the install command in your PR.

## Running tests

Tests use only the standard-library `unittest` module — no test
runner needs to be installed:

```bash
PYTHONPATH=src python3 -m unittest discover -s tests/unit -v
```

## Before opening a PR

1. Add or update tests for any behavior you change. Aim for at least:
   a normal case, an edge case, and a failure case (see `tests/unit`
   for the existing pattern).
2. Run the full test suite and confirm it passes.
3. Manually run the affected `nxff` command against a real file/directory
   at least once — a "fresh machine" sanity check, not just unit tests.
4. Update `README.md` if you changed CLI behavior, flags, or output
   format. Every command shown in the README must actually work as
   written.
5. Update `CHANGELOG.md` under an "Unreleased" heading.

## Adding a new command

New commands live in `src/nxfileforensics/core/<feature>.py` (pure
logic, no argparse/printing) and are wired up in `cli.py`. Keeping
logic and CLI plumbing separate is what makes the core testable without
spawning subprocesses in every test.

## Code style

- Type hints on public functions.
- Docstrings that explain *why*, not just *what*, for anything non-obvious.
- Small, focused functions over large ones.
- No dependency additions "just in case."

## Reporting bugs / requesting features

Open a GitHub issue. For bugs, include your OS, Python version
(`python3 --version`), the exact command you ran, and the full output.
