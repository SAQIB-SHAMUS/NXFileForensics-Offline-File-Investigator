import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.scanner import scan_directory
from nxfileforensics.errors import NotADirectoryErrorNxff, PathNotFoundError


class TestScanner(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_missing_root_raises(self):
        with self.assertRaises(PathNotFoundError):
            scan_directory(self.root / "nope")

    def test_file_instead_of_directory_raises(self):
        f = self.root / "file.txt"
        f.write_text("hi")
        with self.assertRaises(NotADirectoryErrorNxff):
            scan_directory(f)

    def test_empty_directory(self):
        report = scan_directory(self.root)
        self.assertEqual(report.files_scanned, 0)
        self.assertEqual(report.duplicate_groups, [])

    def test_detects_duplicate_files(self):
        (self.root / "a.txt").write_bytes(b"identical content")
        (self.root / "b.txt").write_bytes(b"identical content")
        (self.root / "c.txt").write_bytes(b"unique content")
        report = scan_directory(self.root)
        self.assertEqual(report.files_scanned, 3)
        self.assertEqual(len(report.duplicate_groups), 1)
        self.assertEqual(len(report.duplicate_groups[0]), 2)

    def test_detects_extension_mismatch(self):
        (self.root / "fake.pdf").write_bytes(b"MZ" + b"\x90" * 60)
        report = scan_directory(self.root)
        finding = report.findings[0]
        self.assertTrue(finding.extension_mismatch)

    def test_detects_hidden_file(self):
        (self.root / ".secret").write_bytes(b"shh")
        report = scan_directory(self.root)
        self.assertTrue(report.findings[0].hidden)

    def test_zero_byte_file_flagged(self):
        (self.root / "empty.log").write_bytes(b"")
        report = scan_directory(self.root)
        self.assertTrue(report.findings[0].zero_byte)

    def test_recurses_into_subdirectories(self):
        sub = self.root / "nested" / "deeper"
        sub.mkdir(parents=True)
        (sub / "deep.txt").write_bytes(b"deep content")
        report = scan_directory(self.root)
        self.assertEqual(report.files_scanned, 1)

    def test_max_depth_limits_recursion(self):
        sub = self.root / "level1" / "level2"
        sub.mkdir(parents=True)
        (self.root / "level1" / "shallow.txt").write_bytes(b"shallow")
        (sub / "deep.txt").write_bytes(b"deep")
        report = scan_directory(self.root, max_depth=1)
        paths = [f.path for f in report.findings]
        self.assertTrue(any("shallow.txt" in p for p in paths))
        self.assertFalse(any("deep.txt" in p for p in paths))


if __name__ == "__main__":
    unittest.main()
