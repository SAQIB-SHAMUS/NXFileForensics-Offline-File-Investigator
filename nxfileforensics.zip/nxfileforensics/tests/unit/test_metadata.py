import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.metadata import get_metadata
from nxfileforensics.errors import PathNotFoundError


class TestMetadata(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_missing_path_raises(self):
        with self.assertRaises(PathNotFoundError):
            get_metadata(self.root / "missing.txt")

    def test_basic_fields(self):
        f = self.root / "sample.txt"
        f.write_bytes(b"hello world")
        meta = get_metadata(f)
        self.assertEqual(meta.size_bytes, 11)
        self.assertFalse(meta.is_hidden)
        self.assertFalse(meta.is_symlink)

    def test_hidden_file_detected(self):
        f = self.root / ".hidden"
        f.write_bytes(b"x")
        meta = get_metadata(f)
        self.assertTrue(meta.is_hidden)

    def test_symlink_detected(self):
        target = self.root / "target.txt"
        target.write_bytes(b"data")
        link = self.root / "link.txt"
        try:
            link.symlink_to(target)
        except (OSError, NotImplementedError):
            self.skipTest("symlinks not supported on this platform/permissions")
        meta = get_metadata(link)
        self.assertTrue(meta.is_symlink)

    def test_to_dict_is_json_serializable_shape(self):
        f = self.root / "sample.txt"
        f.write_bytes(b"data")
        meta = get_metadata(f)
        d = meta.to_dict()
        self.assertIn("size_bytes", d)
        self.assertIn("permissions", d)


if __name__ == "__main__":
    unittest.main()
