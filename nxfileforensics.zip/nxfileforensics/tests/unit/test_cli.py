import io
import json
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

from nxfileforensics.cli import main


class TestCli(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def _run(self, argv):
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = main(argv)
        return code, out.getvalue(), err.getvalue()

    def test_hash_command_json(self):
        f = self.root / "a.txt"
        f.write_bytes(b"content")
        code, out, err = self._run(["--json", "hash", str(f), "--algo", "sha256"])
        self.assertEqual(code, 0)
        data = json.loads(out)
        self.assertIn("sha256", data)

    def test_inspect_missing_file_gives_friendly_error_not_traceback(self):
        code, out, err = self._run(["inspect", str(self.root / "nope.txt")])
        self.assertEqual(code, 1)
        self.assertIn("Error:", err)
        self.assertNotIn("Traceback", err)

    def test_entropy_command_text_output(self):
        f = self.root / "zeros.bin"
        f.write_bytes(b"\x00" * 1000)
        code, out, err = self._run(["entropy", str(f)])
        self.assertEqual(code, 0)
        self.assertIn("Entropy:", out)

    def test_scan_command_on_empty_directory(self):
        code, out, err = self._run(["scan", str(self.root)])
        self.assertEqual(code, 0)
        self.assertIn("Scanned 0 file", out)

    def test_diff_identical_files(self):
        a = self.root / "a.bin"
        b = self.root / "b.bin"
        a.write_bytes(b"same")
        b.write_bytes(b"same")
        code, out, err = self._run(["diff", str(a), str(b)])
        self.assertEqual(code, 0)
        self.assertIn("identical", out)

    def test_strings_min_length_validation(self):
        f = self.root / "a.bin"
        f.write_bytes(b"hello")
        code, out, err = self._run(["strings", str(f), "--min-length", "0"])
        self.assertEqual(code, 1)
        self.assertIn("Error:", err)

    def test_global_flags_work_after_subcommand(self):
        # Regression test: --no-color/--json must work in either position,
        # not just before the subcommand name.
        f = self.root / "a.txt"
        f.write_bytes(b"content")
        code, out, err = self._run(["hash", str(f), "--no-color", "--json"])
        self.assertEqual(code, 0, msg=err)
        data = json.loads(out)
        self.assertIn("sha256", data)

    def test_version_flag_exits_zero(self):
        with self.assertRaises(SystemExit) as ctx:
            self._run(["--version"])
        self.assertEqual(ctx.exception.code, 0)


if __name__ == "__main__":
    unittest.main()
