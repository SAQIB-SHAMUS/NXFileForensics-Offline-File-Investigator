import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.signatures import check_extension_mismatch, identify


class TestSignatures(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmpdir.cleanup()

    def _write(self, name: str, content: bytes) -> Path:
        p = Path(self.tmpdir.name) / name
        p.write_bytes(content)
        return p

    def test_identifies_png(self):
        f = self._write("pic.png", b"\x89PNG\r\n\x1a\n" + b"\x00" * 20)
        sig = identify(f)
        self.assertIsNotNone(sig)
        self.assertIn("PNG", sig.name)

    def test_identifies_pdf(self):
        f = self._write("doc.pdf", b"%PDF-1.4\n%rest of file")
        sig = identify(f)
        self.assertIsNotNone(sig)
        self.assertIn("PDF", sig.name)

    def test_unknown_signature_returns_none(self):
        f = self._write("notes.txt", b"just plain text, nothing special")
        self.assertIsNone(identify(f))

    def test_matching_extension_is_not_flagged(self):
        f = self._write("pic.png", b"\x89PNG\r\n\x1a\n" + b"\x00" * 20)
        result = check_extension_mismatch(f)
        self.assertFalse(result.mismatched)

    def test_mismatched_extension_is_flagged(self):
        # A Windows executable saved with a .pdf extension — the classic
        # forensic red flag this whole feature exists to catch.
        f = self._write("invoice.pdf", b"MZ" + b"\x90" * 60)
        result = check_extension_mismatch(f)
        self.assertTrue(result.mismatched)
        self.assertIn("PE", result.detected.name)

    def test_unknown_type_is_never_flagged_as_mismatch(self):
        f = self._write("data.xyz", b"random unrecognized bytes here")
        result = check_extension_mismatch(f)
        self.assertFalse(result.mismatched)
        self.assertIsNone(result.detected)

    def test_offset_signature_wav(self):
        # 'RIFF' header + size + 'WAVE' at byte offset 8
        content = b"RIFF" + b"\x24\x00\x00\x00" + b"WAVE" + b"\x00" * 10
        f = self._write("audio.wav", content)
        sig = identify(f)
        self.assertIsNotNone(sig)
        self.assertIn("WAV", sig.name)


if __name__ == "__main__":
    unittest.main()
