import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.diff import diff_files


class TestDiff(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmpdir.cleanup()

    def _write(self, name: str, content: bytes) -> Path:
        p = Path(self.tmpdir.name) / name
        p.write_bytes(content)
        return p

    def test_identical_files(self):
        a = self._write("a.bin", b"same content here")
        b = self._write("b.bin", b"same content here")
        result = diff_files(a, b)
        self.assertTrue(result.identical)
        self.assertEqual(result.differing_bytes, 0)
        self.assertIsNone(result.first_difference_offset)
        self.assertEqual(result.similarity_pct(), 100.0)

    def test_files_differ_at_known_offset(self):
        a = self._write("a.bin", b"AAAAABBBBB")
        b = self._write("b.bin", b"AAAAAXBBBB")
        result = diff_files(a, b)
        self.assertFalse(result.identical)
        self.assertEqual(result.first_difference_offset, 5)
        self.assertEqual(result.differing_bytes, 1)

    def test_different_sizes_are_not_identical(self):
        a = self._write("a.bin", b"short")
        b = self._write("b.bin", b"a much longer file content")
        result = diff_files(a, b)
        self.assertFalse(result.identical)
        self.assertNotEqual(result.size_a, result.size_b)

    def test_empty_files_are_identical(self):
        a = self._write("a.bin", b"")
        b = self._write("b.bin", b"")
        result = diff_files(a, b)
        self.assertTrue(result.identical)

    def test_completely_different_content_low_similarity(self):
        a = self._write("a.bin", b"\x00" * 100)
        b = self._write("b.bin", b"\xff" * 100)
        result = diff_files(a, b)
        self.assertEqual(result.differing_bytes, 100)
        self.assertEqual(result.similarity_pct(), 0.0)


if __name__ == "__main__":
    unittest.main()
