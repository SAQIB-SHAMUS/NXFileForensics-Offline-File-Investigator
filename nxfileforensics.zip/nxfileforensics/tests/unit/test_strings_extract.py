import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.strings_extract import extract_strings


class TestStringsExtract(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmpdir.cleanup()

    def _write(self, name: str, content: bytes) -> Path:
        p = Path(self.tmpdir.name) / name
        p.write_bytes(content)
        return p

    def test_extracts_simple_string(self):
        f = self._write("a.bin", b"\x00\x00Hello, world!\x00\x00")
        result = list(extract_strings(f, min_length=4))
        self.assertIn("Hello, world!", result)

    def test_short_runs_are_dropped(self):
        f = self._write("b.bin", b"\x00ab\x00cdef\x00")
        result = list(extract_strings(f, min_length=4))
        self.assertNotIn("ab", result)
        self.assertIn("cdef", result)

    def test_min_length_boundary_is_inclusive(self):
        f = self._write("c.bin", b"\x00wxyz\x00")
        result = list(extract_strings(f, min_length=4))
        self.assertIn("wxyz", result)

    def test_string_at_end_of_file_without_trailing_null(self):
        f = self._write("d.bin", b"\x00trailing")
        result = list(extract_strings(f, min_length=4))
        self.assertIn("trailing", result)

    def test_empty_file_yields_nothing(self):
        f = self._write("empty.bin", b"")
        self.assertEqual(list(extract_strings(f)), [])

    def test_invalid_min_length_raises(self):
        f = self._write("e.bin", b"anything")
        with self.assertRaises(ValueError):
            list(extract_strings(f, min_length=0))

    def test_string_spanning_chunk_boundary(self):
        # Force a run of printable bytes to straddle the internal 1 MiB
        # chunk boundary and confirm it is still captured whole.
        from nxfileforensics.core import strings_extract as mod

        pad = b"\x00" * (mod._CHUNK_SIZE - 5)
        content = pad + b"HELLOTHERE" + b"\x00"
        f = self._write("boundary.bin", content)
        result = list(extract_strings(f, min_length=4))
        self.assertIn("HELLOTHERE", result)


if __name__ == "__main__":
    unittest.main()
