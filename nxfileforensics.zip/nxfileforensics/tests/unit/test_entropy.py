import os
import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.entropy import is_high_entropy, shannon_entropy


class TestEntropy(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmpdir.cleanup()

    def _write(self, name: str, content: bytes) -> Path:
        p = Path(self.tmpdir.name) / name
        p.write_bytes(content)
        return p

    def test_empty_file_has_zero_entropy(self):
        f = self._write("empty.bin", b"")
        self.assertEqual(shannon_entropy(f), 0.0)

    def test_single_repeated_byte_has_zero_entropy(self):
        f = self._write("zeros.bin", b"\x00" * 10000)
        self.assertEqual(shannon_entropy(f), 0.0)

    def test_uniform_random_bytes_have_high_entropy(self):
        f = self._write("random.bin", os.urandom(200_000))
        value = shannon_entropy(f)
        self.assertGreater(value, 7.9)
        self.assertTrue(is_high_entropy(f))

    def test_low_entropy_text_is_not_flagged_high(self):
        f = self._write("text.txt", b"aaaaaaaaaa bbbbbbbbbb " * 500)
        self.assertFalse(is_high_entropy(f))

    def test_entropy_is_bounded(self):
        f = self._write("random.bin", os.urandom(50_000))
        value = shannon_entropy(f)
        self.assertGreaterEqual(value, 0.0)
        self.assertLessEqual(value, 8.0)


if __name__ == "__main__":
    unittest.main()
