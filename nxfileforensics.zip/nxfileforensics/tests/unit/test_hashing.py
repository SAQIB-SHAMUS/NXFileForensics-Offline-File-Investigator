import hashlib
import tempfile
import unittest
from pathlib import Path

from nxfileforensics.core.hashing import compute_hashes
from nxfileforensics.errors import UnreadableFileError


class TestHashing(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.file = Path(self.tmpdir.name) / "sample.txt"
        self.content = b"The quick brown fox jumps over the lazy dog" * 100
        self.file.write_bytes(self.content)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_sha256_matches_stdlib(self):
        expected = hashlib.sha256(self.content).hexdigest()
        result = compute_hashes(self.file, algorithms=["sha256"])
        self.assertEqual(result["sha256"], expected)

    def test_multiple_algorithms_single_pass(self):
        result = compute_hashes(self.file, algorithms=["md5", "sha256"])
        self.assertEqual(set(result.keys()), {"md5", "sha256"})
        self.assertEqual(result["md5"], hashlib.md5(self.content).hexdigest())

    def test_empty_file(self):
        empty = Path(self.tmpdir.name) / "empty.bin"
        empty.write_bytes(b"")
        result = compute_hashes(empty, algorithms=["sha256"])
        self.assertEqual(result["sha256"], hashlib.sha256(b"").hexdigest())

    def test_unsupported_algorithm_rejected(self):
        with self.assertRaises(ValueError):
            compute_hashes(self.file, algorithms=["sha3_9000"])

    def test_missing_file_raises_friendly_error(self):
        missing = Path(self.tmpdir.name) / "does_not_exist.bin"
        with self.assertRaises(UnreadableFileError):
            compute_hashes(missing)

    def test_two_different_files_have_different_hashes(self):
        other = Path(self.tmpdir.name) / "other.txt"
        other.write_bytes(b"different content entirely")
        h1 = compute_hashes(self.file, algorithms=["sha256"])["sha256"]
        h2 = compute_hashes(other, algorithms=["sha256"])["sha256"]
        self.assertNotEqual(h1, h2)


if __name__ == "__main__":
    unittest.main()
